$(document).ready(function(){     
	$("body").append("<h1>HELLO</h1>");
});
